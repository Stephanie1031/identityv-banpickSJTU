# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'miniWin.ui'
##
## Created by: Qt User Interface Compiler version 6.3.0
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QLabel, QSizePolicy, QWidget)

class Ui_miniWin(object):
    def setupUi(self, miniWin):
        if not miniWin.objectName():
            miniWin.setObjectName(u"miniWin")
        miniWin.resize(746, 132)
        self.label = QLabel(miniWin)
        self.label.setObjectName(u"label")
        self.label.setGeometry(QRect(0, 0, 800, 130))
        self.label.setMinimumSize(QSize(800, 130))
        self.label.setMaximumSize(QSize(800, 130))
        self.label.setPixmap(QPixmap(u"../pic/miniWin.png"))
        self.label_2 = QLabel(miniWin)
        self.label_2.setObjectName(u"label_2")
        self.label_2.setGeometry(QRect(180, 50, 41, 31))
        font = QFont()
        font.setFamilies([u"Arial Rounded MT Bold"])
        font.setPointSize(15)
        font.setBold(True)
        self.label_2.setFont(font)
        self.label_2.setAlignment(Qt.AlignCenter)
        self.label_3 = QLabel(miniWin)
        self.label_3.setObjectName(u"label_3")
        self.label_3.setGeometry(QRect(180, 90, 41, 31))
        self.label_3.setFont(font)
        self.label_3.setAlignment(Qt.AlignCenter)
        self.label_4 = QLabel(miniWin)
        self.label_4.setObjectName(u"label_4")
        self.label_4.setGeometry(QRect(270, 50, 41, 31))
        self.label_4.setFont(font)
        self.label_4.setAlignment(Qt.AlignCenter)
        self.label_5 = QLabel(miniWin)
        self.label_5.setObjectName(u"label_5")
        self.label_5.setGeometry(QRect(270, 90, 41, 31))
        self.label_5.setFont(font)
        self.label_5.setAlignment(Qt.AlignCenter)
        self.label_6 = QLabel(miniWin)
        self.label_6.setObjectName(u"label_6")
        self.label_6.setGeometry(QRect(370, 50, 41, 31))
        self.label_6.setFont(font)
        self.label_6.setAlignment(Qt.AlignCenter)
        self.label_7 = QLabel(miniWin)
        self.label_7.setObjectName(u"label_7")
        self.label_7.setGeometry(QRect(370, 90, 41, 31))
        self.label_7.setFont(font)
        self.label_7.setAlignment(Qt.AlignCenter)
        self.label_8 = QLabel(miniWin)
        self.label_8.setObjectName(u"label_8")
        self.label_8.setGeometry(QRect(460, 50, 41, 31))
        self.label_8.setFont(font)
        self.label_8.setAlignment(Qt.AlignCenter)
        self.label_9 = QLabel(miniWin)
        self.label_9.setObjectName(u"label_9")
        self.label_9.setGeometry(QRect(460, 90, 41, 31))
        self.label_9.setFont(font)
        self.label_9.setAlignment(Qt.AlignCenter)
        self.label_10 = QLabel(miniWin)
        self.label_10.setObjectName(u"label_10")
        self.label_10.setGeometry(QRect(570, 50, 41, 31))
        self.label_10.setFont(font)
        self.label_10.setAlignment(Qt.AlignCenter)
        self.label_11 = QLabel(miniWin)
        self.label_11.setObjectName(u"label_11")
        self.label_11.setGeometry(QRect(570, 90, 41, 31))
        self.label_11.setFont(font)
        self.label_11.setAlignment(Qt.AlignCenter)
        self.label_12 = QLabel(miniWin)
        self.label_12.setObjectName(u"label_12")
        self.label_12.setGeometry(QRect(660, 50, 41, 31))
        self.label_12.setFont(font)
        self.label_12.setAlignment(Qt.AlignCenter)
        self.label_13 = QLabel(miniWin)
        self.label_13.setObjectName(u"label_13")
        self.label_13.setGeometry(QRect(660, 90, 41, 31))
        self.label_13.setFont(font)
        self.label_13.setAlignment(Qt.AlignCenter)

        self.retranslateUi(miniWin)

        QMetaObject.connectSlotsByName(miniWin)
    # setupUi

    def retranslateUi(self, miniWin):
        miniWin.setWindowTitle(QCoreApplication.translate("miniWin", u"Form", None))
        self.label.setText("")
        self.label_2.setText(QCoreApplication.translate("miniWin", u"-", None))
        self.label_3.setText(QCoreApplication.translate("miniWin", u"-", None))
        self.label_4.setText(QCoreApplication.translate("miniWin", u"-", None))
        self.label_5.setText(QCoreApplication.translate("miniWin", u"-", None))
        self.label_6.setText(QCoreApplication.translate("miniWin", u"-", None))
        self.label_7.setText(QCoreApplication.translate("miniWin", u"-", None))
        self.label_8.setText(QCoreApplication.translate("miniWin", u"-", None))
        self.label_9.setText(QCoreApplication.translate("miniWin", u"-", None))
        self.label_10.setText(QCoreApplication.translate("miniWin", u"-", None))
        self.label_11.setText(QCoreApplication.translate("miniWin", u"-", None))
        self.label_12.setText(QCoreApplication.translate("miniWin", u"-", None))
        self.label_13.setText(QCoreApplication.translate("miniWin", u"-", None))
    # retranslateUi

